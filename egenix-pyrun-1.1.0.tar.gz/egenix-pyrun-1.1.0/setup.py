#!/usr/bin/env python

""" Distutils Setup File for the eGenix PyRun distribution.

"""
#
# Load configuration(s)
#
import egenix_pyrun
configurations = (egenix_pyrun,)

#
# Run distutils setup...
#
import mxSetup
mxSetup.run_setup(configurations)
