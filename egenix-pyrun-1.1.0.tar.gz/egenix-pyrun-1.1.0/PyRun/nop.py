# Does nothing but test Python startup time
