#!/usr/local/bin/python2.1

""" Configuration for the eGenix PyRun Distribution

    Copyright (c) 1997-2000, Marc-Andre Lemburg; mailto:mal@lemburg.com
    Copyright (c) 2000-2012, eGenix.com Software GmbH; mailto:info@egenix.com
    See the documentation for further information on copyrights,
    or contact the author. All Rights Reserved.
"""
from mxSetup import mx_Extension, mx_version

#
# Package version
#
version = mx_version(1, 1, 0)

#
# Setup information
#
name = "egenix-pyrun"

#
# Meta-Data
#
description = "eGenix PyRun Distribution"
long_description = """\
The eGenix PyRun distribution provides a way
to build a one-file Python interpreter that can
easily be used to run CGIs, stand-alone applications
and shipped with prepackaged tools.

This software is brought to you by eGenix.com and
distributed under the eGenix.com Public License 1.1.0.
"""
license = (
"eGenix.com Public License 1.1.0; "
"Copyright (c) 2008-2012, eGenix.com Software GmbH, All Rights Reserved"
)
author = "eGenix.com Software GmbH"
author_email = "info@egenix.com"
maintainer = "eGenix.com Software GmbH",
maintainer_email = "info@egenix.com"
url = "http://www.egenix.com/products/python/PyRun/"
download_url = url
platforms = [
#    'Windows',
    'Linux',
    'FreeBSD',
#    'Solaris',
    'Mac OS X',
#    'AIX',
    ]
classifiers = [
    "Environment :: Console",
    "Environment :: No Input/Output (Daemon)",
    "Intended Audience :: Developers",
    "License :: OSI Approved :: Python License (CNRI Python License)",
    "License :: Freely Distributable",
    "License :: Other/Proprietary License",
    "Natural Language :: English",
    "Operating System :: OS Independent",
    "Operating System :: Microsoft :: Windows",
    "Operating System :: POSIX",
    "Operating System :: Unix",
    "Operating System :: BeOS",
    "Operating System :: MacOS",
    "Operating System :: OS/2",
    "Operating System :: Other OS",
    "Programming Language :: C",
    "Programming Language :: Python",
    "Topic :: Software Development",
    "Topic :: Software Development :: Libraries",
    "Topic :: Software Development :: Libraries :: Application Frameworks",
    "Topic :: Software Development :: Libraries :: Python Modules",
    "Topic :: Utilities ",
    ]
if 'a' in version:
    classifiers.append("Development Status :: 3 - Alpha")
elif 'b' in version:
    classifiers.append("Development Status :: 4 - Beta")
else:
    classifiers.append("Development Status :: 5 - Production/Stable")
    classifiers.append("Development Status :: 6 - Mature")
classifiers.sort()

